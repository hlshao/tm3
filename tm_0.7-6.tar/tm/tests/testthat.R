library(testthat)
library(tm)

test_check("tm")
